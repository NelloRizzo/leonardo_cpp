#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
template <class T>
class My {
	T value;
public:
	My(const T& t) : value(t) {}

	T get() { return value; }

	My<T> operator +(My<T> other) { return My<T>(value + other.value); }

	friend ostream& operator <<(ostream& s, My<T>& my) {
		return s << "My(" << my.get() << ")";
	}
};

int acc = 0;
void sum(My<int> m) { acc += m.get(); }

class Sum {
	int accumulator;
public:
	Sum(int init = 0) :accumulator(init) {}
	void sum(My<int> item) {
		accumulator += item.get();
	}
	void operator()(My<int> item) {
		cout << "operator() -> " << item << endl;
		sum(item);
	}
	int get() { return accumulator; }
};

int main() {
	My<int> m1(1);
	My<int> m2(2);
	My<int> m3(3);
	vector<My<int>> vm;
	vm.push_back(m1);
	vm.push_back(m2);
	vm.push_back(m3);

	for (vector<My<int>>::iterator i = vm.begin(); i != vm.end(); i++) {
		cout << *i << endl;
	}
	// type inference
	for (auto i = vm.begin(); i != vm.end(); i++) {
		cout << *i << endl;
	}
	acc = 0;
	for_each(vm.begin(), vm.end(), sum);
	cout << "Risultato: " << acc << endl;
	Sum s;
	s = for_each(vm.begin(), vm.end(), s);
	cout << s.get() << endl;
}