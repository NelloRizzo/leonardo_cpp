#include <iostream>
#include <sstream>
#include <string>

using namespace std;

class MustDescribeHimself { // classe astratta (o virtuale pura) perch� contiene almeno un metodo astratto
public:
	virtual string getDescription() = 0; // astratto (virtuale puro)
};

class Auto :public MustDescribeHimself {
public:
	string getDescription() override { return "Sono un'automobile"; }
};

class Person :public MustDescribeHimself {
private:
	string name;
	string surname;
public:
	Person(string name, string surname) :name(name), surname(surname) {}

	virtual string getDescription() {
		stringstream s;
		s << *this;
		return s.str();
	}

	friend ostream& operator << (ostream& s, const Person p) {
		return s << p.name << ' ' << p.surname;
	}
};

class Vip :public Person {
private:
	string title;
public:
	Vip(string name, string surname, string title) :Person(name, surname), title(title) {}

	string getDescription() {
		stringstream s;
		s << *this;
		return s.str();
	}

	friend ostream& operator << (ostream& s, const Vip v) {
		return s << v.title << ' ' << (Person)v;
	}
};

void handleDescribable(MustDescribeHimself& p) {
	cout << p.getDescription() << endl;
}

int main1()
{
	Person archimede("Archimede", "Pitagorico");
	Vip paperone("Paperon", "De' Paperoni", "sig.");
	cout << archimede.getDescription() << endl;
	cout << paperone.getDescription() << endl;

	//MustDescribeHimself m;
	//handleDescribable(m);
	Auto a;
	handleDescribable(a);
	handleDescribable(archimede);
	handleDescribable(paperone);
	return 0;
}