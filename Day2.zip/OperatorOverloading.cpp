#include <iostream>
using namespace std;
class RatioException :public exception {
public:
	RatioException(const char* what) :exception(what) {}
};
class DenominatorZeroException :public RatioException {
public:
	DenominatorZeroException(const char* what) :RatioException(what) {}
};
class Ratio {
private:
	int numerator;
	int denominator;
	int signum;
	static int _gcf(int a, int b) {
		if (b == 0) return a;
		return _gcf(b, a % b);
	}
public:
	static int gcf(int a, int b) {
		if (a > b)
			return _gcf(a, b);
		return _gcf(b, a);
	}
	Ratio(int n, int d) :
		signum(n* d >= 0 ? 1 : -1),
		numerator(abs(n)),
		denominator(abs(d)) {
		if (d == 0)
			//cout << "Attenzione, non posso creare la frazione se il denominatore � 0" << endl;
			throw DenominatorZeroException("Divisore pari a 0");
		int g = gcf(numerator, denominator);
		numerator /= g;
		denominator /= g;
	}

	Ratio(double n) : Ratio(int(n * 10000), 10000) {}

	Ratio operator+(const Ratio& other) const {
		return Ratio(signum * numerator * other.denominator + other.signum * other.numerator * denominator, denominator * other.denominator);
	}

	Ratio operator-() const {
		return Ratio(-signum * numerator, denominator);
	}

	Ratio operator-(const Ratio& other) const {
		return *this + (-other);
	}

	operator double() {
		return 1.0 * signum * numerator / denominator;
	}

	friend ostream& operator<<(ostream& s, const Ratio& r) {
		if (r.numerator == 0) return s << 0;
		if (r.signum < 0) s << '-';
		s << r.numerator;
		if (r.denominator != 1)
			s << '/' << r.denominator;
		return s;
	}

	bool operator==(const Ratio& other) const
	{
		return numerator == other.numerator && denominator == other.denominator && signum == other.signum;
	}
};

int main2() {
	try {
		cout << (double)Ratio(1, 0) << endl;
	}
	catch (DenominatorZeroException e) {
		cout << "Non potendo eseguire il precedente, perche' " << e.what() << ", dico " << (double)Ratio(1 / .0001) << endl;
	}
	catch (RatioException) {
		cout << "Ops... si e' verificato un problema" << endl;
	}
	Ratio r1(1, 3);
	Ratio r2(1, -3);
	Ratio r3(-10, 30);
	cout << r1 << ' ' << r2 << ' ' << r3 << endl;

	cout << Ratio(1, 3) + Ratio(1, 4) << endl;
	cout << -r3 << endl;
	cout << r1 - r2 << endl;
	cout << (double)r1 << endl;

	cout << r1 << " e " << r2 << " sono ";
	if (r1 == r2)
		cout << "uguali" << endl;
	else
		cout << "diversi" << endl;
	cout << r1 << " e " << -r2 << " sono ";
	if (r1 == -r2)
		cout << "uguali" << endl;
	else
		cout << "diversi" << endl;

	cout << Ratio(1.234) << endl;
	Ratio r = 1.234;
	cout << r << endl;
	return 0;
}