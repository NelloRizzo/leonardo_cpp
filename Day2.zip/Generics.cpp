#include <iostream>
#include <string>
using namespace std;

class PairStringInt {
	string first;
	int second;
public:
	PairStringInt(string f, int s) :first(f), second(s) {}

	friend ostream& operator<<(ostream& s, const PairStringInt& p) {
		return s << "Pair(" << p.first << ',' << p.second << ')';
	}
};
class PairIntString {
	int first;
	string second;
public:
	PairIntString(int f, string s) :first(f), second(s) {}

	friend ostream& operator<<(ostream& s, const PairIntString& p) {
		return s << "Pair(" << p.first << ',' << p.second << ')';
	}
};

template <class T1, class T2>
class Pair
{
public:
	T1 first;
	T2 second;

	Pair(T1 f, T2 s) :first(f), second(s) {}

	friend ostream& operator<<(ostream& s, const Pair<T1, T2>& p) {
		return s << "Pair(" << p.first << ',' << p.second << ')';
	}
};

unsigned short Hash(void* p) {
	unsigned int val = reinterpret_cast<unsigned int>(p);
	return (unsigned short)(val ^ (val >> 16));
}

template <class T, int VAL> void print(T info) {
	for (int i = 0; i < VAL; ++i)
		cout << i << '\t' << info << endl;
}
int main3() {
	PairStringInt psi("Test", 10);
	cout << psi << endl;
	PairIntString pis(10, "Test");
	cout << pis << endl;

	Pair<int, string> tis(10, "Template");
	Pair<string, int> tsi("Template", 10);
	Pair<Pair<string, int>, double> tpd(Pair<string, int>("T1", 1), 1.3412);
	cout << tis << '-' << tsi << endl;
	cout << tpd << endl;

	cout << static_cast<int>(tpd.second) << endl;

	int a[20];
	for (int i = 0; i < 20; i++)
		cout << Hash(a + i) << endl;

	print<string, 10>("Ciao");
	print<string, 5>("Ciao");
	print<Pair<string, string>, 5>(Pair<string, string>("Primo", "Secondo"));
	return 0;
}