#include <iostream>

// supponiamo di voler implementare un sistema
// che sia in grado di svolgere delle operazioni
// aritmetiche sfruttando un componente Calcolatore
// che consenta lo svolgimento delle operazioni 
// e dia la possibilit� di guardare al risultato ottenuto

// Cosa significa, nel mio mondo, "calcolatore"?
// Un [calcolatore] � un componente che, gestendo un
// [accumulatore], pu� effettuare su di esso le 
// operazioni: di <addizionare>, <sottrarre>, <moltiplicare>
// e <dividere>...
// Un accumulatore cos'�?
// un accumulatore � un numero...
/*
+========================+
| Calcolatore            |
+========================+
| accumulatore     N     |
+------------------------+
| add()                  |
| sub()                  |
| div()                  |
| mul()                  |
+========================+
*/
class Calculator {
private:
	double _accumulator;

public:
	std::string _name;
	Calculator() : Calculator("Calculator") {}

	Calculator(std::string name) : _accumulator(0.0), _name(name) {
		// _accumulator = 0;
		std::cout << "Costruttore di Calculator " << _name << std::endl;
	}
	Calculator(const Calculator& c) : _accumulator(c._accumulator), _name(c._name + "_inner") {
		std::cout << "Costruttore di copia di Calculator a partire da " << c._name << std::endl;
	}
	~Calculator() {
		std::cout << "Distruttore di Calculator " << _name << std::endl;
	}
	// legge il valore dell'accumulatore e lo restituisce 
	// per un utilizzo esterno
	// IN:
	//    nessuno
	// OUT:
	//    il valore dell'accumulatore
	inline double accumulator() const { return _accumulator; }
	// add riceve un numero da addizionare all'accumulatore
	// IN:
	//    numero da addizionare
	// OUT:
	//    nessuno (void)
	virtual void add(double number) { _accumulator += number; }
	virtual void sub(double number) { _accumulator -= number; }
	virtual void div(double number) { _accumulator /= number; }
	virtual void mul(double number) { _accumulator *= number; }
};
void my_system(Calculator  c) {
	//c._name = "inner";
	std::cout << "Sto usando " << c._name << std::endl;
	// addiziona 10
	c.add(10);
	// sottrai 20
	c.sub(20);
	// moltiplica 30
	c.mul(30);
	// dividi 40
	c.div(40);
	// mostra il risultato...
	std::cout << c.accumulator() << std::endl;
}
void my_system(Calculator* c) {
	c->_name = "inner pointer";
	// addiziona 10
	c->Calculator::add(10);
	c->add(10.5);
	// sottrai 20
	c->sub(20);
	// moltiplica 30
	c->mul(30);
	// dividi 40
	c->div(40);
	// mostra il risultato...
	std::cout << c->accumulator() << std::endl;
}


class RibbonCalculator : public Calculator {
public:
	// senza virtual si fa shadowing
	void add(double number) { 
		std::cout << "Adding " << number << " to " << accumulator();
		Calculator::add(number); 
		std::cout << ". Result is " << accumulator() << std::endl;
	}
	void sub(double number) override { 
		std::cout << "Subtracting " << number << " from " << accumulator();
		Calculator::sub(number); 
		std::cout << ". Result is " << accumulator() << std::endl;
	}
	void mul(double number) override { 
		std::cout << "Multiplying " << number << " by " << accumulator();
		Calculator::mul(number); 
		std::cout << ". Result is " << accumulator() << std::endl;
	}
	void div(double number) override { 
		std::cout << "Dividing " << accumulator() << " by " << number;
		Calculator::div(number); 
		std::cout << ". Result is " << accumulator() << std::endl;
	}
	void power(int pow) {
		double val = accumulator();
		while (--pow > 0)
			mul(val);
	}
};

int main()
{
	int i(10);
	std::cout << i << std::endl;
	Calculator c("outer");
	//c.name = "outer calculator";
	//c._accumulator = 12345;
	my_system(c);

	Calculator* pc = new Calculator("outer pointer");
	std::cout << "Prima dell'invocazione del sistema, lavoro con " << pc->_name << std::endl;
	my_system(pc);
	std::cout << "Dopo l'invocazione del sistema, posso lavorare con " << pc->_name << std::endl;
	delete pc;

	RibbonCalculator* rc = new RibbonCalculator();
	std::cout << "my_system funziona anche con RibbonCalculator" << std::endl;
	rc->add(100);
	my_system(rc);
	rc->power(2);
	std::cout << "Dopo l'elevamento a potenza: " << rc->accumulator() << std::endl;

	return 0;
}