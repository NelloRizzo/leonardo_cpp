#include <iostream>

using namespace std;

class MyString {
private:
	char* str;
	int len;

	void destroy() { delete str; }
	void copy(MyString const& other) {
		len = strlen(other.str);
		this->str = new char[len + 1];
		strcpy_s(this->str, len + 1, other.str);
	}
public:
	MyString(const char* str) :str(nullptr), len(strlen(str)) {
		cout << "Costruttore di MyString" << endl;
		this->str = new char[len + 1];
		strcpy_s(this->str, len + 1, str);
	}

	MyString(const MyString& m) : str(nullptr), len(m.len) {
		cout << "Costruttore di copia di MyString" << endl;
		//this->str = new char[len + 1];
		//strcpy_s(this->str, len + 1, m.str);
		copy(m);
	}

	MyString& const operator=(const MyString& s) {
		cout << "Operatore di assegnazione" << endl;
		// verifica che 's' e 'this' non siano lo stesso oggetto
		if (this != &s) {
			// distrugge l'oggetto attuale (perch� altrimenti this->str resterebbe appeso
			cout << "Prima elimino il contenuto di this: " << str << endl;
			//delete this->str;
			destroy();
			//len = strlen(s.str);
			//this->str = new char[len + 1];
			//strcpy_s(this->str, len + 1, s.str);
			copy(s);
			cout << "Poi ricostruisco this: " << str << endl;
		}
		// deve restituire un riferimento alla variabile perch� cos� pu� essere 
		//      effettuata un'operazione in catena (a = b = c)
		return *this;
	}

	~MyString() {
		//delete str;
		destroy();
		cout << "Distruttore di MyString" << endl;
	}

	void uppercase() {
		char* s = str;
		for (; *s; ++s)
		{
			if (*s >= 'a' && *s <= 'z')
				*s = *s + 'A' - 'a';
		}
	}

	friend ostream& operator <<(ostream& s, const MyString& m) {
		return s << "MyString(" << m.str << ")";
	}
};

void handleMyString(MyString s) {
	s.uppercase();
	cout << "Dentro handleMyString: " << s << endl;
}

int copyconstructors() {
	MyString s("Prova");
	{
		MyString s1 = s; // === MyString s1(s);
		s1.uppercase();
		cout << "Prima di handleMyString: " << s << endl;
		s1 = s; // s1.operator=(s)
	}
	cout << "Qui la stringa gestita da s1 e' morta" << endl;
	handleMyString(s);
	cout << "Dopo handleMyString: " << s << endl;
	return 0;
}