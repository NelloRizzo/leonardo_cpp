// 
// Supponiamo che in CPP non esista l'aritmetica delle date.
// Vogliamo gestire il concetto di data avendo la possibilit� di 
// aggiungere e sottrarre giorni ad una specifica data inizializzata in precedenza.
//

#include <iostream>

#include "Date.h"

int main()
{
	Date today;
	Date yesterday(today.subDays(1));
	Date tomorrow = today.addDays(1);
	std::cout << "Oggi: " << today << " - Ieri: " << yesterday << " - Domani: " << tomorrow << std::endl;
	std::cout << today + 30 << endl;
}

