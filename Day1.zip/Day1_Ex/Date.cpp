#include "Date.h"

#include <ctime>
#include <ostream>
#include <iomanip>

using namespace std;

const int* month_days(int year) {
	const int days[] = { 31, 28 + Date::isLeapYear(year) ? 1 : 0, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	return days;
}
bool Date::isValid(int year, int month, int day)
{
	if (month < 1 || month > 12) return false;
	return day > 0 && day <= month_days(year)[month - 1];
}

Date::Date()
{
	auto t = time(0);
	struct tm now;
	localtime_s(&now, &t);
	_year = now.tm_year + 1900;
	_day = now.tm_mday;
	_month = now.tm_mon + 1;
}

Date::Date(int year, int month, int day) :Date()
{
	if (isValid(year, month, day)) {
		_year = year;
		_month = month;
		_day = day;
	}
}

Date Date::addDays( int days) const
{
	int y = _year;
	int m = _month;
	int d = _day;
	int days_of_month = month_days(y)[m - 1];
	while (days-- > 0) {
		if (d < days_of_month) {
			d++;
		}
		else
		{
			if (m < 11) {
				++m;
			}
			else {
				m = 1;
				++y;
			}
			d = 1;
			days_of_month = month_days(y)[m - 1];
		}
	}
	return Date(y, m, d);
}

Date Date::addMonths( int months) const
{
	int y = _year;
	int m = _month;
	while (months-- > 0) {
		if (m < 11)
			++m;
		else {
			m = 1;
			++y;
		}
	}
	return Date(y, m, _day);
}

Date Date::addYears( int years) const
{
	return Date(_year + years, _month, _day);
}

Date Date::subDays( int days) const
{
	int y = _year;
	int m = _month;
	int d = _day;
	int days_of_month = month_days(y)[m - 1];
	while (days-- > 0) {
		if (d > 1) {
			d--;
		}
		else
		{
			if (m > 1) {
				--m;
			}
			else {
				m = 12;
				--y;
			}
			d = month_days(y)[m - 1];
		}
	}
	return Date(y, m, d);
}

Date Date::subMonths( int months) const
{
	int y = _year;
	int m = _month;
	while (months-- > 0) {
		if (m > 1) {
			--m;
		}
		else {
			m = 12;
			--y;
		}
	}
	return Date(y, m, _day);
}

Date Date::subYears( int years) const
{
	return Date(_year - years, _month, _day);
}

ostream& operator<<(ostream& s, const Date& d)
{
	return s << setfill('0') << setw(2) << d._day << '/' << setfill('0') << setw(2) << d._month << '/' << d._year;
}


bool Date::operator==(const Date& other) const
{
	return _year == other._year && _month == other._month && _day == other._day;
}

Date Date::operator+(int days)
{
	if (days > 0)
		return addDays(days);
	return subDays(-days);
}

Date Date::operator-(int days)
{
	if (days > 0)
		return subDays(days);
	return addDays(-days);
}
