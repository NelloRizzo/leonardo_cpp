#pragma once

#include <ostream>

using namespace std;

class Date
{
private:
	int _year;
	int _month;
	int _day;
public:
	static bool isValid(int, int, int);
	static inline bool isLeapYear(int year) { return year % 4 == 0 && year % 400 != 0; }

	Date();
	Date(int, int, int);
	inline int year() const { return _year; }
	inline int day() const { return _day; }
	inline int month() const { return _month; }
	Date addDays( int) const;
	Date addMonths( int) const;
	Date addYears( int) const;
	Date subDays( int) const;
	Date subMonths( int) const;
	Date subYears( int) const;

	friend ostream& operator<<(ostream& s, const Date& d);
	bool operator==(const Date& other) const;
	Date operator+(int days);
	Date operator-(int days);
};

